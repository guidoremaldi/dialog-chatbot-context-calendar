class Message:

    def Hello(self, intents):
        print("Здравствуйте! Я чатбот с учётом контекста") #ЧТО Я УМЕЮ
        print("Вот что я умею:")
        for intent in intents:
            print(intent)


    def Input_intent(self):
        print("Введите команду:")

    def No_slot(self, slots):
        for slot in slots:
            print(slot, ' нету')

    def No_intent(self):
        print("Не нашёл интент в строке. Может, попробуете ещё раз?")

    def Anything_else(self):
        print("Что-нибудь ещё?")

    def Slot_request(self, slots):
        print("Уточните пожалуйста ", slots)

    def Clairify(self): #Уточнить, вероятно вы имеете ввиду этот интент, надо дополнить слоты
        print()


    def Good_Bye(self):
        print("До свидания!")

    def Intent_done(self, intent_name):
        print("Интент ",intent_name," исполнен")