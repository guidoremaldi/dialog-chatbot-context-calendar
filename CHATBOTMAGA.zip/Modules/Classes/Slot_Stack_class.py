class Slot_Stack:
    def __init__(self):
        self.intent_and_vars = {}

    def Check_and_Append(self, var_value):

    if slot_variable_name in self.vars:
        self.vars[slot_variable_name] = slot_variable_value
    else:
        self.vars.update({slot_variable_name: slot_variable_value})






    def check_type(something, the_type):
        if the_type == "str":
            if isinstance(something, str):
                return "name"
        if the_type == "dict":
            if isinstance(something, dict):
                return "time"

"""
 self.intent_and_vars = [{"Intent":
 {"Name": имя, "time": время, "status": fulfilled/declined}}]
 
 
 затравочная штука 
 [{"Intent":"Intent_name,
    "Attributes":{
    "Name": undefined, 
    "time": undefined}}]


declined - если поступил новый интент 
 
 ЧЕМ РАСПОЗНАВАТЬ ДАННЫЕ
 
 
 
 
 
 его же - данные из  self.intent_and_vars[len(self.intent_and_vars)-1]
 
 }







    def Check_and_Append(self, var_name_and_value):
        slot_variable_name = var_name_and_value[:var_name_and_value.find('=')]  # Имя переменной(до знака "=")
        slot_variable_value = var_name_and_value[var_name_and_value.find('=') + 1:]  # Значение переменной (после "=")
        if slot_variable_name in self.vars:
            self.vars[slot_variable_name] = slot_variable_value
        else:
            self.vars.update({slot_variable_name: slot_variable_value})

    def Print_Slot_Stack(self):
        print("Стек текущих слотов:")
        for slot_var_name in self.vars:
            print(slot_var_name, ' = ', self.vars[slot_var_name])

"""