import subprocess
import calendar
import datetime
import re
now=datetime.datetime.now()

class DateTime_Parser:
    verbal_days = {"позапозавчера": -3, "позавчера": -2, "вчера": -1, "сегодня": 0, "завтра": 1, "послезавтра": 2,
                   "послепослезавтра": 3}

    verbal_month = {1: "Январь",
                        2: "Февраль",
                        3: "Март",
                        4: "Апрель",
                        5: "Май",
                        6: "Июнь",
                        7: "Июль",
                        8: "Август",
                        9: "Сентябрь",
                        10: "Октябрь",
                        11: "Ноябрь",
                        12: "Декабрь"}



    def __init__(self):




        self.raw_string = ''
        self.year = now.year
        self.month = now.month
        self.day = now.day
        self.hour = now.hour
        self.minute = now.minute


    def format_date(self):
        formats={}


    def get_span(self,A,B):
        pass

    def get_date(self):
        """ЕСЛИ ДАТА РАЗДЕЛЁННАЯ ТОЧКАМИ ИЛИ СЛЕШАМИ"""
        if self.date.find('.') != -1 or self.date.find('/') != -1:
            date_list = re.split('[. /]', self.date)
            print(date_list)
            if len(date_list) == 3:
                if int(date_list[0])//2000==1:
                    self.year = date_list[0]
                    self.month = date_list[1]
                    self.day = date_list[2]
                else:
                    if int(date_list[2])//2000==1:
                        self.year = date_list[2]
                        self.month = date_list[1]
                        self.day = date_list[0]
                    else:
                        return print("НЕПРАВИЛЬНЫЙ ФОРМАТ")
                    """ЕСЛИ С МЕСЯЦЕМ СТРОКОЙ"""
            if len(date_list) == 2:
                for element in date_list:
                    if element.isalpha():
                        print(element)
                        for month_number in DateTime_Parser.verbal_month:
                            if DateTime_Parser.verbal_month[month_number].lower().find(element[:3].lower())!=-1:
                                self.month = month_number
                                if date_list.index(element) == 0:
                                    self.day = date_list[1]
                                else:
                                    self.day = date_list[0]
                                return
                """ЕСЛИ ДЕНЬ МЕСЯЦ ЧИСЛАМИ"""
                self.day = date_list[0]
                self.month = date_list[1]
            return


        """ЕСЛИ ВЧЕРА СЕГОДНЯ ЗАВТРА И ТД"""
        if self.date.lower() in DateTime_Parser.verbal_days:  # строка с датой всеми нижними буковками
            self.day += DateTime_Parser.verbal_days[self.date.lower()]
            """НА ПРОШЛЫЕ ВЕЩИ"""
            if self.day <= 0:
                self.month -= 1
                if self.month == 0:
                    self.year = self.year-1
                    self.month = 12
                self.day = calendar.mdays[self.month] - self.day
            """НА БУДУЮЩИЕ ВЕЩИ"""
            if self.day > calendar.mdays[self.month]:
                self.month += 1
                if self.month > 12:
                    self.year = self.year + 1
                    self.month = 1
                self.day = self.day - calendar.mdays[self.month-1]

    """ДЛЯ КОНКРЕТНОГО ВРЕМЕНИ ИЛИ ДЛЯ ВСЕГО """
    def get_time(self):
        if self.raw_string.find('.') != -1:
                self.hour = self.time[:self.time.find('.')].lower()
                self.minute = self.time[self.time.find('.') + 1:].lower()
        else:
            if "all" in self.time.lower():
                self.hour = "all"
                self.minute = "all"


    def break_string(self):
        if self.raw_string.find('#') != -1:
            self.date = self.raw_string[:self.raw_string.find('#')]  # Имя переменной(до знака "#")
            self.time = self.raw_string[self.raw_string.find('#') + 1:]  # Значение переменной (после "#")
        else:
            return print(ValueError)

    def process_string(self, string):
        self.raw_string = string
        # print(self.raw_string)
        self.break_string()
        # print(self.date,'/',self.time)
        self.get_date()
        self.get_time()
        DateTime = {"year": str(self.year), "month": str(self.month), "day": str(self.day), "hour": str(self.hour), "minute": str(self.minute)}
        return DateTime
        #self.print_time()

    def print_time(self):
        print(self.year, '.', self.month, '.', self.day, '/', self.hour, ':', self.minute)



