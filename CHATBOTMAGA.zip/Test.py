import os
import clr
from System import DateTime
pathDLL = os.getcwd() + "\\HorsLib\\Hors.dll"
clr.AddReference(pathDLL)
import datetime
from Hors import HorsTextParser
import json
import pprint
hors = HorsTextParser()
print(pathDLL)





mydict = {'a':1,'b':3,'c':2}

dictus = {32:{2:"dfd",
              1:"33",
              3:"Aaaa"},
          13:{2:"dfd",
              1:{9:"33",3:"1"}}}

# s2 = sorted(dictus[year], key=lambda key: dictus[year][key])
    #dictus[year]=s2
#dictus=sorted(dictus, key=lambda key: dictus[key])
#s1= sorted(dictus, key=dictus.get)

#print(s1)
#print(dictus)



#sorted_income = {k: incomes[k] for k in sorted(incomes)}

"""
inp_str=input()

result = hors.Parse(inp_str, DateTime.Now)
#text = result.Text; #// -> string: "будет красивый закат"
#formatText = result.TextWithTokens; #// -> string: "{0} будет красивый закат"
#date = result.Dates[0].DateFrom; #// -> DateTime: 26.03.2019 23:00:00
print("Размер списка ",len(result.Dates))
for i in range(len(result.Dates)-1):
    print(result.Dates[i])
if result.Dates:
    print(result.Dates[0].HasTime)
    print(result.Dates[0].Type)
else:
    time="undefined"
print(result.Dates[0])
print(result.Dates[0].DateFrom)
print(result.Dates[0].DateTo)
deadline = datetime.datetime.strptime(str(result.Dates[0].DateFrom), "%d.%m.%Y %H:%M:%S")
"""


#print(result.Dates[0].DateFrom)
#print(result.Dates[1].DateFrom)

#now=datetime.datetime.now()
#print(deadline)
#print(deadline.hour)

"""ПОТОМ В ФАЙЛЕ РАСПАРСЮ СТРПТАЙМом"""

def parse_datetime(string):
    types = {0: "Fixed",
             1: "Period",
             2: "SpanForward",
             3: "SpanBackward"
             }
    datetime_parsed_raw={}
    datetime_parsed = {"Type":"unknown", "HasTime":"unknown", "DateFrom": {"year":0, "month":0, "day":0, "hour":0, "minute":0}, "DateTo": {"year":0, "month":0, "day":0, "hour":0, "minute":0}}
    result = hors.Parse(string, DateTime.Now)
    print("Я тут")
    if result.Dates:
        print("Дата есть")

        datetime_parsed_raw["DateFrom"] = datetime.datetime.strptime(str(result.Dates[0].DateFrom), "%d.%m.%Y %H:%M:%S")
        datetime_parsed_raw["DateTo"] = datetime.datetime.strptime(str(result.Dates[0].DateTo), "%d.%m.%Y %H:%M:%S")

        datetime_parsed["Type"] = types[result.Dates[0].Type]
        datetime_parsed["HasTime"] = result.Dates[0].HasTime
        datetime_parsed["DateFrom"]["year"] = datetime_parsed_raw["DateFrom"].year
        datetime_parsed["DateFrom"]["month"] = datetime_parsed_raw["DateFrom"].month
        datetime_parsed["DateFrom"]["day"] = datetime_parsed_raw["DateFrom"].day
        datetime_parsed["DateFrom"]["hour"] = datetime_parsed_raw["DateFrom"].hour
        datetime_parsed["DateFrom"]["minute"] = datetime_parsed_raw["DateFrom"].minute

        datetime_parsed["DateTo"]["year"] = datetime_parsed_raw["DateTo"].year
        datetime_parsed["DateTo"]["month"] = datetime_parsed_raw["DateTo"].month
        datetime_parsed["DateTo"]["day"] = datetime_parsed_raw["DateTo"].day
        datetime_parsed["DateTo"]["hour"] = datetime_parsed_raw["DateTo"].hour
        datetime_parsed["DateTo"]["minute"] = datetime_parsed_raw["DateTo"].minute

    else:
        datetime_parsed = "undefined"
    rest_of_the_input=result.Text
    return datetime_parsed, rest_of_the_input


def diff_vs_now(datetime_parsed):
    now=datetime.datetime.now()
    negative_difference_data = False
    diff_year=datetime_parsed.year-now.year
    diff_month = datetime_parsed.month - now.month
    diff_day = datetime_parsed.day - now.day
    diff_hour = datetime_parsed.hour - now.hour
    diff_minute = datetime_parsed.minute - now.minute
    difference = {"year": diff_year, "month": diff_month, "day": diff_day, "hour": diff_hour, "minute": diff_minute}
    for key in difference:
        if difference[key]<0:
            negative_difference_data=[True, key, difference[key]]
            break
    return negative_difference_data

#print(diff_vs_now(deadline))

#if (diff_vs_now(deadline)[1] =="hour" or diff_vs_now(deadline)[1] =="minute") and deadline.hour+12<=24:
#    print("На сегодня на ", deadline.hour+12,"или на завтра на ",deadline.hour,"?")



inp_str= input()
print(parse_datetime(inp_str)[0])
print(parse_datetime(inp_str)[1])

def check_type(something, the_type):
    if the_type == "str":
        if isinstance(something, str):
            return "name"
    if the_type=="dict":
        if isinstance(something, dict):
            return "time"

print(check_type("sdfsd","str"))

"""
dictus = {
    "2021": {
        "6": {
            "4": {
                "15": {
                    "00": {
                        "Event_name": "СОБЫТИЕ",
                        "Event_Duration": 1,
                        "Event_Location": "Неизвестно",
                        "Event_Description": "Неизвестно"
                    }
                },
                "16": {
                    "00": {
                        "Event_name": "СОБЫТИЕ",
                        "Event_Duration": 1,
                        "Event_Location": "Неизвестно",
                        "Event_Description": "Неизвестно"
                    }
                }}}}}
"""


"""






def sort_calendar(dictus):
    for year in dictus:
        for month in dictus[year]:
            for day in dictus[year][month]:
                for hour in dictus[year][month][day]:
                    sorted_minutes = {minute: dictus[year][month][day][hour][minute] for minute in sorted(dictus[year][month][day][hour])}
                    dictus[year][month][day][hour] = sorted_minutes
                sorted_hours = {hour: dictus[year][month][day][hour] for hour in sorted(dictus[year][month][day])}
                dictus[year][month][day] = sorted_hours
            sorted_days = {day: dictus[year][month][day] for day in sorted(dictus[year][month])}
            dictus[year][month] = sorted_days
        sorted_months = {month: dictus[year][month] for month in sorted(dictus[year])}
        dictus[year]=sorted_months
    sorted_years= {year:dictus[year] for year in sorted(dictus)}
    dictus=sorted_years
    return dictus


    data = json.load(f)
    print(data)
    data_sorted=sort_calendar(data)


print(data_sorted)




from DateTime_Parser_class import DateTime_Parser
#db[time["year"]][time["month"]][time["day"]][time["hour"]][time["minute"]]
#event_data={"time": time, "event_info": new_event}

standart_event = dict({"Event_name": "Письку натрагуваю...", "Event_Duration": 1, "Event_Location": "Неизвестно", "Event_Description": "Неизвестно"})

db={"2021":{ "12":{ "3":{ "15":{ "00":standart_event}}}}}



year, month, day, hour, minute = ("2021", "12", "3", "15", "00") #Тут я время получаю
time={"year": year,
      "month": month,
      "day": day,
      "hour": hour,
      "minute": minute
      }
event_data={"time": time, "event_info": standart_event}

def check_coincidence(event_data):
    time = event_data["time"]
    if time["year"] in db:
        if time["month"] in db[time["year"]]:
            if time["day"] in db[time["year"]][time["month"]]:
                if time["hour"] in db[time["year"]][time["month"]][time["day"]]:
                    if time["minute"] in db[time["year"]][time["month"]][time["day"]][
                        time["hour"]]:
                        if "Event_name" in 
                                db[time["year"]][time["month"]][time["day"]][time["hour"]][
                                    time["minute"]]:
                            print("Есть событие")
                            return True

    print("Нет события")
    return False

print(event_data["time"].values())

"""






"""



DateTime=DateTime_Parser()

string= input()
datetime=DateTime.process_string(string)
print(datetime)






class get_span():

    def all_month(self, digit):
        pass
    def all_day(self):
        hours=[]
        for i in range(0,24):
            if i<10:
                hours.append("0"+str(i))
            else:
                hours.append(str(i))
        print(hours)
        minutes=[]
        for i in range(0, 60):
            if i < 10:
                minutes.append("0" + str(i))
            else:
                minutes.append(str(i))
        print(minutes)
    def range_hours(self,a,b):
        hours = []
        for i in range(a, b):
            if i < 10:
                hours.append("0" + str(i))
            else:
                hours.append(str(i))
        print(hours)


    def get_span(self,digit):
        a=[]
        for i in range(digit):
            a.append(i)
        print(a)

spans=get_span()
spans.range_hours(15,20)
"""

"""
print(db)
print(event_data)
print(check_coincidence(event_data))
def month_to_str(month):
    verbal_month = {1: "Январь",
                    2: "Февраль",
                    3: "Март",
                    4: "Апрель",
                    5: "Май",
                    6: "Июнь",
                    7: "Июль",
                    8: "Август",
                    9: "Сентябрь",
                    10: "Октябрь",
                    11: "Ноябрь",
                    12: "Декабрь"}
    if verbal_month[month][len(verbal_month[month])-1]=='ь' or verbal_month[month][len(verbal_month[month])-1]=='й':
        month_out = verbal_month[month][:len(verbal_month[month]) - 1] + "е"
        return month_out
    else:
        month_out = verbal_month[month]+"e"
        return month_out


def format_output():
   for year in db:
        print("В %d году:" %year)
        for month in db[year]:
            print(" В %s:" %month_to_str(month))
            for day in db[year][month]:
                print("     "+str(day)+'-го:')
                for hour in db[year][month][day]:
                    for minute in db[year][month][day][hour]:
                        print('        {}:{}'.format( hour, minute), db[year][month][day][hour][minute])


format_output()

"""





#for month in range(1,12):
#    print(month_to_str(month))


"""
year, month, day, hour, minute = (2021, 12, 3, 15, 00) #Тут я время получаю
time={"year": year,
      "month": month,
      "day": day,
      "hour": hour,
      "minute": minute
      }

time1={"year": year,
      "month": month,
      "day": day
       }










#print(db[time["year"]][time["month"]][time["day"]][time["hour"]][time["minute"]])
#for minute in db[time["year"]][time["month"]][time["day"]][time["hour"]]:
  #  print('        {}:{}'.format(minute, hour),
    #      db[time["year"]][time["month"]][time["day"]][time["hour"]][minute])





year, month, day, hour, minute = ([2021,2022], 12, 3, 15, 00) #Тут я время получаю
time={"year": year,
      "month": month,
      "day": day,
      "hour": hour,
      "minute": minute
      }





def Sasaitama():
    print("MUJABAHILll")

@Override
def Sasaitama(i):




import collections

dd = collections.defaultdict(dict)
dd['a']['b'] = "foo"


event_dict = dict({ 2021:{
                        12:{
                            3:{
                                15:{
                                    00: {
                                        "Event_name": "Аллах велик"
                                    }
                                }
                            }

}
}})

year, month, day, hour, minute= (2021, 12, 3, 15, 00)
print(event_dict)
standart_event = dict({"Event_name": "Default", "Duration": 1, "Location": "Неизвестно", "Description": "Неизвестно"})
# Either

if year in event_dict:
    if month in event_dict[year]:
        if day in event_dict[year][month]:
            if hour in event_dict[year][month][day]:
                if minute in event_dict[year][month][day][hour]:
                    event_dict[year][month][day][hour][minute]["Event_name"] = "Аллах ОЧЕНЬ велик"

                else:
                    event_dict[year][month][day][hour][minute] = {"Event_name": "Допригався на нову минутку..."}
            else:
                event_dict[year][month][day][hour] = {minute: {"Event_name": "Допригався на новий часiк..."}}
        else:
            event_dict[year][month][day] = {hour: {minute: {"Event_name": "Допригався на новий денб..."}}}
    else:
        event_dict[year][month] = {day: {hour: {minute: {"Event_name": "Допригався на новий мiсяць..."}}}}
else:
    event_dict[year] = {month: {day: {hour: {minute: {"Event_name": "Допригався на новий год..."}}}}}


print(event_dict)
#else:
    # dd[location] does not exist yet!
    #dd[location] = {item: cost}
#print(dd)
# Or
#dd.setdefault(location, {})[item] = cost

# Or with defaultdict
#ee = collections.defaultdict(dict)0
#ee[location][item] = cost  # creates automagically




test_dict = dict(
    {2021: {
        "June": {
            "1":
                {13.00: 777,
                 "13.30": 1488},
            "2":
                {"Bucelatti": 777,
                 "Akagairi": 1488}
        }}})
test_dict2 = dict({-1:-1})
print(test_dict2[-1]+1)
print(test_dict[2021]["June"]["1"][13.00])

dd = {}
location, item, cost = ("gymnasium", "weights", 15)
print(dd)



print(calendar.mdays[datetime.date.today().month])


b='1999-05-03 10:37:00'
print(re.split('[- :]', b))


2 элемент - это и есть количество дней. Или можешь вот так:
calendar.mdays[datetime.date.today().month]




print(now.strftime("%d.%m.%Y %H:%M"))
    def Intent_Recognize(self, message_from_user_splitted):
        for i in range(len(message_from_user_splitted)):
            if message_from_user_splitted[i].find('=') == -1:
                intent_word = message_from_user_splitted[i]
                self.current_intent = self.intent_keyword_search(intent_word)



Сегодня
Завтра
Послезавтра
послепослезавтра

понедельник
вторник
среда
четверг
Пятница
суббота
Воскресенье
"""

"""

test_dict = dict(
    {2021: {
        "June": {
            "1":
                {13.00: 777,
                 "13.30": 1488},
            "2":
                {"Bucelatti": 777,
                 "Akagairi": 1488}
        }}})
test_dict2 = dict({-1:-1})
print(test_dict2[-1]+1)
print(test_dict[2021]["June"]["1"][13.00])

print("Текущая секунда: %d" % now.second)

print("Секунда поболбше: %d" % (now.second+1))

print("Текущая дата и время с использованием метода str:")
print(str(now))
print(str(parsed_datetime))

print("Текущая дата и время с использованием атрибутов:")

print("Текущая секунда: %d" % now.second)
print("Текущая дата: " , now.date())
print("Текущее время: " , now.time())

print("Текущая дата и время с использованием strftime:")
print(now.strftime("%d.%m.%Y %H:%M"))



print("Текущая дата и время с использованием strftime:")


print("Текущая дата и время с использованием isoformat:")
print(now.isoformat())



class TestClass():
    def __init__(self, file_name):
        self.file_name = file_name
        self.yasos = 1488
        self.vars = {}

    def bubu(self):
        return "NIGGA"

    def detect_variables(self):
        with open(self.file_name, 'r', encoding='utf-8') as f:
            # открыли файл с данными
            text = json.load(f)  # загнали все, что получилось в переменную
            #pprint(text)  # вывели результат на экран
            for var_name in text["Variables"]:
                new_var = {var_name: "No value"}
                self.vars.update(new_var)


    def get_message(self):
        user_input = str(input())
        message_from_user = [str(s) for s in user_input.split()]
        print(message_from_user)

    def print_vars(self):
        for var in self.vars:
            print(var, self.vars[var])


test_dict = {}
name="KOK"

test=TestClass(file_intent_create)
test.get_message()




for file_name in file_intents:
    name_of_intent = path.basename(file_name).split('.')[0]
    test_dict[name_of_intent] = TestClass(file_name)
    test_dict[name_of_intent].detect_variables()



    print(name_of_intent)

 print(test_dict["KOK"].bubu())
    print(test_dict["KOK"].yasos)
    test_dict[name].print_vars()
    print(full_name.split('.')[0])
    
def intent_keyword_search(self, file_intent_array, intent_word):
    for intent_file in file_intent_array:
        full_name = path.basename(intent_file)
        intent_name = path.splitext(full_name)[0]
        with io.open(intent_file, 'r', encoding='utf-8') as file:
            for line in file:
                if intent_word.lower() in line.lower():
                    return intent_name

    return "Нет интента"

"""
